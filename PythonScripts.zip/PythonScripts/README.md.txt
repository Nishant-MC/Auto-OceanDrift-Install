# Open Drift App

This application runs the OpenDrift model every minute with the latest data.

## Setup

1. Ensure you have a basic Python environment set up and have `conda` installed.

2. Install OpenDrift by following the documentation [here](https://opendrift.github.io/install.html). If you encounter issues with installing `mamba`, use the following command:
   ```bash
   conda install -n base --override-channels -c conda-forge mamba 'python_abi=*=*cp*'
   ```

3. Install GDAL by following the documentation:
   ```bash
   git clone https://github.com/OSGeo/GDAL.git
   ```

4. Navigate to your folder `C:\the-crossing\Content\PythonScripts` and install the required dependencies:
   ```bash
   pip install -r requirements.txt
   ```

5. Run the script:
   ```bash
   python drift_app.py
   ```